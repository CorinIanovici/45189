//
//  ViewController.swift
//  RGB_Slider
//
//  Created by Developer on 21/5/2562 BE.
//  Copyright © 2562 Developer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var lbl:UILabel?
    var lbl2:UILabel?
    
    var redSlider:UISlider?
    var greenSlider:UISlider?
    var blueSlider:UISlider?
    var alphaSlider:UISlider?
  
    
    
    lazy var arr:[UIView] = [lbl!, lbl2!, redSlider!, greenSlider!, blueSlider!, alphaSlider!]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.lightGray
        
        
        self.redSlider = UISlider (frame: CGRect(x: 20, y: 360, width: 255, height: 20))
        self.redSlider?.thumbTintColor = UIColor.red
        self.redSlider?.minimumTrackTintColor = UIColor.red
        self.redSlider?.maximumValue = 255
        self.redSlider?.minimumValue = 0
        self.redSlider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)

        
        self.greenSlider = UISlider (frame: CGRect(x: 20, y: 400, width: 255, height: 20))
        self.greenSlider?.thumbTintColor = UIColor.green
        self.greenSlider?.minimumTrackTintColor = UIColor.green
        self.greenSlider?.maximumValue = 255
        self.greenSlider?.minimumValue = 0
        self.greenSlider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)
        
        self.blueSlider = UISlider (frame: CGRect(x: 20, y: 440, width: 255, height: 20))
        self.blueSlider?.thumbTintColor = UIColor.blue
        self.blueSlider?.minimumTrackTintColor = UIColor.blue
        self.blueSlider?.maximumValue = 255
        self.blueSlider?.minimumValue = 0
        self.blueSlider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)
        
        self.alphaSlider = UISlider (frame: CGRect(x: 20, y: 480, width: 255, height: 20))
        self.alphaSlider?.minimumTrackTintColor = UIColor.white
        self.alphaSlider?.maximumValue = 1.0
        self.alphaSlider?.minimumValue = 0
        self.alphaSlider?.addTarget(self, action: #selector(MainLabel), for: .valueChanged)

        self.lbl2 = UILabel(frame: CGRect(x: 20, y: 280, width: 255, height: 50))
        self.lbl2?.textColor = UIColor.black
        self.lbl2?.textAlignment = NSTextAlignment.center
        self.lbl2?.text = "R: \(Int(redSlider?.value ?? 0)) G: \(Int(greenSlider?.value ?? 0)) B: \(Int(blueSlider?.value ?? 0)) A: \(Int(alphaSlider?.value ?? 0))"
        
        self.lbl = UILabel(frame: CGRect(x: 70, y: 100, width: 180, height: 180))
        self.lbl?.layer.masksToBounds = true
        self.lbl?.layer.cornerRadius = 90
        self.lbl?.layer.borderWidth = 5
        
        
        
        for a in arr {
            self.view.addSubview(a)
        }
    }
    
    

    @objc
    func MainLabel() {
        
        self.lbl?.backgroundColor = UIColor (red: CGFloat( (redSlider?.value)!)/255, green: CGFloat((greenSlider?.value)!)/255, blue: CGFloat((blueSlider?.value)!)/255, alpha: CGFloat((alphaSlider?.value)!))
        
        self.lbl2?.text = "R: \(Int(redSlider?.value ?? 0)) G: \(Int(greenSlider?.value ?? 0)) B: \(Int(blueSlider?.value ?? 0)) A: \(String(format: "%.2f", Double(alphaSlider?.value  ?? 0) ))"
        
    }
    

    
    


}

